<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
  <title>Eren</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
  <link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
  <link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
  <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
  <link rel="stylesheet" type="text/css" href="css/bootsnav.css">
  <link rel="stylesheet" type="text/css" href="css/settings.css">
  <link rel="stylesheet" type="text/css" href="css/loader.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">

  <link rel="shortcut icon" href="images/favicon.png">


  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

</head>

<body>

  <!--Loader-->
  <div class="loader">
    <div class="spinner-load">
      <div class="dot1"></div>
      <div class="dot2"></div>
    </div>
  </div>


  <div class="container-fluid">

    <header class="right-menu">
      <div class="container-fluid">
        <div class="row">
          <!-- Start Navigation -->
          <nav class="navbar navbar-default  bootsnav">
            <!-- Start Atribute Navigation -->
            <div class="attr-nav">
              <ul>
                <li class="cart-toggler">
                  <a href="#.">
                    <i class="fa fa-shopping-cart"></i>
                    <span class="badge">3</span>
                  </a>
                </li>
                <li class="search"><a href="#."><i class="fa fa-search"></i></a>
                </li>
                <li class="side-menu"><a href="#."><i class="fa fa-bars"></i></a>
                </li>
              </ul>
            </div>

            <!-- Start Header Navigation -->
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                <i class="fa fa-bars"></i>
              </button>
              <a class="navbar-brand" href="index3.html"><img src="images/logo-black.png" class="logo" alt="">
              </a>
            </div>
            <!-- End Header Navigation -->

            <div class="collapse navbar-collapse" id="navbar-menu">
              <ul class="nav navbar-nav navbar-right" data-in="fadeIn" data-out="fadeOut">
                <li class="dropdown active">
                  <a href="#." class="dropdown-toggle" data-toggle="dropdown">Home</a>
                  <ul class="dropdown-menu">
                    <li><a href="index.html">Home V1</a>
                    </li>
                    <li><a href="index2.html">Home V2</a>
                    </li>
                    <li><a href="index3.html">Home V3</a>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="#." class="dropdown-toggle" data-toggle="dropdown">Products</a>
                  <ul class="dropdown-menu">
                    <li><a href="grid.html">Grid Default</a>
                    </li>
                    <li><a href="grid_list.html">Grid Lists</a>
                    </li>
                    <li><a href="grid_sidebar.html">Grid Sidebar</a>
                    </li>
                    <li><a href="list_sidebar.html">Lists Sidebar</a>
                    </li>
                  </ul>
                </li>
                <li><a href="#.">collection</a>
                </li>
                <li class="dropdown megamenu-fw">
                  <a href="#." class="dropdown-toggle" data-toggle="dropdown">pages</a>
                  <ul class="dropdown-menu megamenu-content" role="menu">
                    <li>
                      <div class="row">
                        <div class="col-menu col-md-3">
                          <h5 class="title heading_border">Blog</h5>
                          <div class="content">
                            <ul class="menu-col">
                              <li><a href="blog1.html">Blog Two Cols</a>
                              </li>
                              <li><a href="blog2.html">Blog Three Cols</a>
                              </li>
                              <li><a href="blog_post.html">Blog Posts</a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-menu col-md-3">
                          <h5 class="title heading_border">Products Elements</h5>
                          <div class="content">
                            <ul class="menu-col">
                              <li><a href="checkout.html">Product Chekouts</a>
                              </li>
                              <li><a href="product_detail.html">Products Details</a>
                              </li>
                              <li><a href="cart.html">Shopping Cart</a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-menu col-md-3">
                          <h5 class="title heading_border">Theme Elements</h5>
                          <div class="content">
                            <ul class="menu-col">
                              <li><a href="#.">Skills</a>
                              </li>
                              <li><a href="#.">Team & Testimonials</a>
                              </li>
                              <li><a href="404.html">Errors</a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div class="col-menu col-md-3">
                          <div class="content">
                            <img src="images/mega-menu.png" alt="menu" class="img-responsive">
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </li>
                <li><a href="#.">about us</a>
                </li>
                <li><a href="contact.html">contact us</a>
                </li>
              </ul>
            </div>

            <!-- Start Side Menu -->
            <div class="side">
              <a href="#." class="close-side"><i class="fa fa-times"></i></a>
              <div class="widget">
                <h6 class="title">Custom Pages</h6>
                <ul class="link">
                  <li><a href="#.">About</a>
                  </li>
                  <li><a href="#.">Services</a>
                  </li>
                  <li><a href="#.">Blog</a>
                  </li>
                  <li><a href="#.">Portfolio</a>
                  </li>
                  <li><a href="#.">Contact</a>
                  </li>
                </ul>
              </div>
              <div class="widget">
                <h6 class="title">Additional Links</h6>
                <ul class="link">
                  <li><a href="#.">Retina Homepage</a>
                  </li>
                  <li><a href="#.">New Page Examples</a>
                  </li>
                  <li><a href="#.">Parallax Sections</a>
                  </li>
                  <li><a href="#.">Shortcode Central</a>
                  </li>
                  <li><a href="#.">Ultimate Font Collection</a>
                  </li>
                </ul>
              </div>
            </div>
            <!-- End Side Menu -->

            <!--Search Bar-->
            <div class="search-toggle">
              <div class="top-search">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Search">
                  <span class="input-group-addon"><i class="fa fa-search"></i></span>
                </div>
              </div>
            </div>
            <ul class="cart-list">
              <li>
                <a href="#." class="photo"><img src="images/hover-cart.jpg" class="cart-thumb" alt="" />
                </a>
                <h6><a href="#.">Sacrificial Chair Design </a></h6>
                <p>Qty: 2 <span class="price">$170.00</span>
                </p>
              </li>
              <li class="total clearfix">
                <div class="pull-right"><strong>Shipping</strong>: $5.00</div>
                <div class="pull-left"><strong>Total</strong>: $173.00</div>
              </li>
              <li class="cart-btn">
                <a href="#." class="active">VIEW CART </a>
                <a href="#.">CHECKOUT </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>


    <!--Slider-->
    <section class="rev_slider_wrapper">
      <div id="rev_slider" class="rev_slider" data-version="5.0">
        <ul>
          <!-- SLIDE  -->
          <li data-transition="fade">
            <!-- MAIN IMAGE -->
            <img src="images/home3-banner1.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
            <div class="tp-caption tp-resizeme" data-x="right" data-hoffset="" data-y="0" data-voffset="10" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-start="3000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;"><img src="images/home2-banner1layer1.png" alt="">
            </div>
            <!-- LAYER NR. 1 -->
            <h3 class="tp-caption tp-resizeme uppercase" data-x="left" data-y="180" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">featured design ideal
        </h3>
            <h1 class="tp-caption tp-resizeme uppercase" data-x="left" data-y="210" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"><strong>Wooden</strong> <span class="white">collection</span>
        </h1>
            <div class="tp-caption  tp-resizeme" data-x="left" data-y="390" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800">
              <p>Claritas est etiam processus dynamicus, qui sequitur mutationem
                <br>consuetudium lectorum.</p>
            </div>
            <div class="tp-caption tp-resizeme" data-x="left" data-y="480" data-width="full" data-transform_idle="o:1;" data-transform_in="y:[-200%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;" data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="800"><a href="#." class="btn-common">Shop Now</a>
            </div>
          </li>
          <li data-transition="fade">
            <img src="images/banner2.jpg" alt="" data-bgposition="center center" data-bgfit="cover">
            <div class="tp-caption tp-resizeme" data-x="500" data-hoffset="" data-y="0" data-voffset="10" data-width="['auto','auto','auto','auto']" data-height="['auto','auto','auto','auto']" data-transform_idle="o:1;" data-transform_in="x:right;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-start="3000" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 7; white-space: nowrap;"><img src="images/baner1-layer.png" alt="">
            </div>
            <h3 class="tp-caption tp-resizeme uppercase" data-x="left" data-y="185" data-width="full" data-transform_idle="o:1;" data-transform_in="y:-50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="800">new arrivals
        </h3>
            <h1 class="tp-caption tp-resizeme uppercase" data-x="left" data-y="228" data-width="full" data-transform_idle="o:1;" data-transform_in="y:-50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1100"><strong>new style</strong> for lamp
        </h1>
            <div class="tp-caption tp-resizeme" data-x="left" data-y="415" data-width="full" data-transform_idle="o:1;" data-transform_in="y:-50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1400">
              <p>Claritas est etiam processus dynamicus, qui sequitur mutationem
                <br>consuetudium lectorum.</p>
            </div>
            <div class="tp-caption tp-resizeme" data-x="left" data-y="510" data-width="full" data-transform_idle="o:1;" data-transform_in="y:-50px;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-start="1700"><a href="#." class="btn-common">Shop Now</a>
            </div>
          </li>
        </ul>
      </div>
    </section>


    <!-- Delivery Service-->
    <section id="msg" class="padding_top">
      <div class="container">
        <div class="message">
          <div class="row">
            <div class="col-md-12 text-center">
              <a class="tag-btn" href="#."><span class="uppercase">hurry up</span></a>
              <h4>FREE UK DELIVERY + RETURN OVER £75.00 (EXCLUDING HOMEWARE)| FREE UK COLLECT FROM STORE</h4>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--New Arrivals-->
    <section id="arrivals" class="padding">
      <div class="container-fluid arrival_container">
        <div class="row">
          <div class="col-md-6">
            <div class="arrival_wrap margintop10">
              <img src="images/arrival-main.jpg" alt="new arrivals">
              <div class="overlay_arrival">
                <div class="inner">
                  <h3 class="uppercase">new arrivals</h3>
                  <h1 class="uppercase">lookbook</h1>
                  <h2 class="uppercase content_space"> custom furniture design</h2>
                  <a href="#." class="btn-white uppercase">shop now </a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product5.jpg">
                  <img src="images/product5.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product5.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <a class="fancybox" href="images/product6.jpg"><img src="images/product6.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product6.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product7.jpg">
                  <img src="images/product7.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product7.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product8.jpg">
                  <img src="images/product8.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product8.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product9.jpg">
                  <img src="images/product9.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product9.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap margintop10">
              <div class="image">
                <a class="fancybox" href="images/product2.jpg"><img src="images/product2.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product2.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--Prallax-->
    <section id="parallax2" class="padding">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 text-center">
            <h2 class="heading_space uppercase">creative design<strong>lighting furniture</strong></h2>
            <h3 class="content_space">Typi non habent claritatem insitam.</h3>
            <a href="#." class="btn-common uppercase">view collection</a>
          </div>
        </div>
      </div>
    </section>


    <!--Features Products-->
    <section id="feature_product" class="padding_top">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="heading_space uppercase">Features Products</h2>
            <p class="content_space">Claritas est etiam processus dynamicus, qui sequitur.</p>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product1.jpg"><img src="images/product1.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product1.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <a class="fancybox" href="images/product2.jpg"><img src="images/product2.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product2.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <a class="fancybox" href="images/product8.jpg"><img src="images/product8.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product8.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <a class="fancybox" href="images/product4.jpg"><img src="images/product4.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product4.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product9.jpg"><img src="images/product9.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product9.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-2 col-sm-6">
            <div class="product_wrap bottom_half">
              <div class="image">
                <div class="tag">
                  <div class="tag-btn">
                    <span class="uppercase text-center">New</span>
                  </div>
                </div>
                <a class="fancybox" href="images/product5.jpg"> <img src="images/product5.jpg" alt="Product" class="img-responsive">
                </a>
              </div>
              <div class="product_desc">
                <p>Sacrificial Chair Design </p>
                <span class="price"><i class="fa fa-gbp"></i>170.00</span>
                <a class="fancybox" href="images/product5.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--Testinomials-->
    <section id="testinomialBg" class="padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="tstinomial-slider" class="owl-carousel">
              <div class="item text-center">
                <div class="testinomial_pic heading_space">
                  <img src="images/testinomial1.png" alt="testinomial">
                  <h6 class="uppercase">michel smith</h6>
                  <span class="uppercase">Developer</span>
                </div>
                <p>Typi non habent claritatem insitam, est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica.</p>
              </div>
              <div class="item text-center">
                <div class="testinomial_pic heading_space">
                  <img src="images/testinomial1.png" alt="testinomial">
                  <h6 class="uppercase">michel Deneal</h6>
                  <span class="uppercase">Developer</span>
                </div>
                <p>Typi non habent claritatem insitam, est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica.</p>
              </div>
              <div class="item text-center">
                <div class="testinomial_pic heading_space">
                  <img src="images/testinomial1.png" alt="testinomial">
                  <h6 class="uppercase">michel smith</h6>
                  <span class="uppercase">Designer</span>
                </div>
                <p>Typi non habent claritatem insitam, est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--OUR BLOG-->
    <section id="blog" class="padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="heading_space uppercase">from our blog</h2>
            <p class="content_space">Claritas est etiam processus dynamicus, qui sequitur</p>
          </div>
          <div class="col-md-6">
            <div class="media blog_box">
              <div class="media-left">
                <a href="blog_post.html">
                  <img class="media-object" src="images/blog1.jpg" alt="...">
                </a>
              </div>
              <div class="media-body">
                <h2 class="media-heading uppercase bottom30">27<sub>/ april</sub></h2>
                <h5 class="uppercase bottom30"><a href="blog_post.html">Claritas est etiam processus <br>dynamicus.</a></h5>
                <p class="bottom30">Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum...</p>
                <a href="blog_post.html" class="readmor uppercase">read more <i class="fa fa-angle-double-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="media blog_box">
              <div class="media-left">
                <a href="blog_post.html">
                  <img class="media-object" src="images/blog2.jpg" alt="...">
                </a>
              </div>
              <div class="media-body">
                <h2 class="media-heading uppercase bottom30">27<sub>/ april</sub></h2>
                <h5 class="uppercase bottom30"><a href="blog_post.html">Claritas est etiam processus <br>dynamicus.</a></h5>
                <p class="bottom30">Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum...</p>
                <a href="blog_post.html" class="readmor uppercase">read more <i class="fa fa-angle-double-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--BRANDS-->
    <section id="brands" class="padding_bottom">
    <h3 class="hidden">hidden</h3>
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="brand-slider" class="owl-carousel">
              <div class="item text-center"><img src="images/logo1.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo2.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo3.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo4.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo5.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo1.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo2.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo3.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo4.png" alt="Brand Logo">
              </div>
              <div class="item text-center"><img src="images/logo5.png" alt="Brand Logo">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--NEWSLETER-->
    <section id="newsletter" class="padding">
      <div class="container">
        <div class="row">
          <div class="col-md-2"></div>
          <div class="col-md-8 text-center">
            <h2 class="heading_space uppercase">sign up to newsletter</h2>
            <p class="bottom_half">Subscribe to the Eren mailing list to receive updates on new arrivals,
              <br> special offers and other discount information.</p>
            <form class="newsletter">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Subscribe to our newsletter..." required>
                <span class="input-group-addon" id="basic-addon2"><button type="submit"><i class="fa fa-paper-plane-o"></i></button></span>
              </div>
            </form>
          </div>
          <div class="col-md-2"></div>
        </div>
      </div>
    </section>


    <!--Testinomial-->
    <section id="availability" class="padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-4">
            <div class="availability text-center margin_top">
              <i class="fa fa-headphones"></i>
              <h5 class="uppercase">free shipping worldwide</h5>
              <span>Free shipping worldwide</span>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="availability text-center margin_top">
              <i class="fa fa-headphones"></i>
              <h5 class="uppercase">24/7 CUSTOMER SERVICE</h5>
              <span>Free shipping worldwide</span>
            </div>
          </div>
          <div class="col-sm-4">
            <div class="availability text-center margin_top">
              <i class="fa fa-headphones"></i>
              <h5 class="uppercase">MONEY BACK GUARANTEE!</h5>
              <span>Free shipping worldwide</span>
            </div>
          </div>
        </div>
      </div>
    </section>


    <!--Footer-->
    <footer class="padding plain_footer">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-1"></div>
          <div class="col-md-6 col-sm-10">
            <div class="footer_panel text-center">
              <a href="index3.html"><img src="images/logo.png" alt="logo" class="content_space">
              </a>
              <p class="content_space">Typi non habent claritatem insitam, est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus.</p>
              <ul class="social">
                <li><a href="#."><i class="fa fa-facebook"></i></a>
                </li>
                <li><a href="#."><i class="fa fa-twitter"></i></a>
                </li>
                <li><a href="#."><i class="fa fa-rss"></i></a>
                </li>
                <li><a href="#."><i class="fa fa-google-plus"></i></a>
                </li>
                <li><a href="#."><i class="fa fa-linkedin"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-1"></div>
        </div>
      </div>
    </footer>
    <div class="copyright">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <p>Copyright &copy; 2016 <a href="#.">Erene</a>. All Right Reserved.</p>
          </div>
        </div>
      </div>
    </div>


  </div>
  <script src="js/jquery-2.2.3.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOBKD6V47-g_3opmidcmFapb3kSNAR70U"></script>
  <script src="js/gmap3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootsnav.js"></script>
  <script src="js/jquery.parallax-1.1.3.js"></script>
  <script src="js/jquery.appear.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.cubeportfolio.min.js"></script>
  <script src="js/jquery.fancybox.js"></script>
  <script src="js/jquery.themepunch.tools.min.js"></script>
  <script src="js/jquery.themepunch.revolution.min.js"></script>
  <script src="js/revolution.extension.layeranimation.min.js"></script>
  <script src="js/revolution.extension.navigation.min.js"></script>
  <script src="js/revolution.extension.parallax.min.js"></script>
  <script src="js/revolution.extension.slideanims.min.js"></script>
  <script src="js/revolution.extension.video.min.js"></script>
  <script src="js/kinetic.js"></script>
  <script src="js/jquery.final-countdown.js"></script>
  <script src="js/functions.js"></script>
</body>


</html>