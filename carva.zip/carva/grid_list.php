<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<title>Eren | grid</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
<link rel="stylesheet" type="text/css" href="css/cubeportfolio.min.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="css/bootsnav.css">
<link rel="stylesheet" type="text/css" href="css/settings.css">
<link rel="stylesheet" type="text/css" href="css/loader.css">
<link rel="stylesheet" type="text/css" href="css/style.css">

<link rel="shortcut icon" href="images/favicon.png">



<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

</head>

<body>

<!--Loader-->
<div class="loader">
  <div class="spinner-load">
    <div class="dot1"></div>
    <div class="dot2"></div>
  </div>
</div>



<!--TOPBAR-->
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <div class="header-top-entry">
          <div class="title">
            ENGLISH<i class="fa fa-angle-down"></i>
          </div>
          <div class="list">
            <a class="list-entry" href="#.">English</a>
            <a class="list-entry" href="#.">Spanish</a>
          </div>
        </div>
        <div class="header-top-entry">
          <div class="title">
            USD<i class="fa fa-angle-down"></i>
          </div>
          <div class="list">
            <a class="list-entry" href="#.">$ CAD</a>
            <a class="list-entry" href="#.">€ EUR</a>
          </div>
        </div>
      </div>
      <div class="col-sm-8">
        <ul class="top_link">
          <li><a href="#." class="uppercase">My Account</a></li>
          <li><a href="#." class="uppercase">wishlish</a></li>
          <li><a href="#." class="uppercase">checkout</a></li>
          <li><a href="#." class="uppercase">login</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!--HEADER-->
<header>
  <nav class="navbar navbar-default navbar-sticky bootsnav">
    <div class="container">
      <div class="attr-nav">
        <ul>
          <li class="cart-toggler">
            <a href="#.">
            <i class="fa fa-shopping-cart"></i>
            <span class="badge">3</span>
            </a>
            </li>
          <li class="search"><a href="#."><i class="fa fa-search"></i></a></li>
        </ul>
      </div>
    
    <!-- Start Header Navigation -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
        <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="index.html"><img src="images/logo.png" class="logo" alt=""></a>
      </div><!-- End Header Navigation -->
    
      <div class="collapse navbar-collapse" id="navbar-menu">
        <ul class="nav navbar-nav navbar-right" data-in="fadeIn" data-out="fadeOut">
          <li class="dropdown">
            <a href="#." class="dropdown-toggle" data-toggle="dropdown">Home</a>
            <ul class="dropdown-menu">
              <li><a href="index.html">Home V1</a></li>
              <li><a href="index2.html">Home V2</a></li>
              <li><a href="index3.html">Home V3</a></li>
            </ul>
          </li>
          <li class="dropdown active">
            <a href="#." class="dropdown-toggle" data-toggle="dropdown">Products</a>
            <ul class="dropdown-menu">
              <li><a href="grid.html">Grid Default</a></li>
              <li><a href="grid_list.html">Grid Lists</a></li>
              <li><a href="grid_sidebar.html">Grid Sidebar</a></li>
              <li><a href="list_sidebar.html">Lists Sidebar</a></li>
            </ul>
          </li>
          <li><a href="#.">collection</a></li>
          <li class="dropdown megamenu-fw">
            <a href="#." class="dropdown-toggle" data-toggle="dropdown">pages</a>
            <ul class="dropdown-menu megamenu-content" role="menu">
              <li>
                <div class="row">
                  <div class="col-menu col-md-3">
                    <h5 class="title heading_border">Blog</h5>
                    <div class="content">
                      <ul class="menu-col">
                        <li><a href="blog1.html">Blog Two Cols</a></li>
                        <li><a href="blog2.html">Blog Three Cols</a></li>
                        <li><a href="blog_post.html">Blog Posts</a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-menu col-md-3">
                    <h5 class="title heading_border">Products Elements</h5>
                    <div class="content">
                      <ul class="menu-col">
                        <li><a href="checkout.html">Product Chekouts</a></li>
                        <li><a href="product_detail.html">Products Details</a></li>
                        <li><a href="cart.html">Shopping Cart</a></li> 
                      </ul>
                    </div>
                  </div>
                  <div class="col-menu col-md-3">
                    <h5 class="title heading_border">Theme Elements</h5>
                    <div class="content">
                      <ul class="menu-col">
                        <li><a href="#.">Skills</a></li>
                        <li><a href="#.">Team & Testimonials</a></li>
                        <li><a href="404.html">Errors</a></li>
                      </ul>
                    </div>
                  </div>    
                  <div class="col-menu col-md-3">
                    <div class="content">
                      <img src="images/mega-menu.png"  alt="menu" class="img-responsive">
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </li>
          <li><a href="#.">about us</a></li>
          <li><a href="contact.html">contact us</a></li>
        </ul>
      </div>
      <div class="search-toggle">
        <div class="top-search">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search">
            <span class="input-group-addon"><i class="fa fa-search"></i></span>
          </div>
        </div>
      </div>
      <ul class="cart-list">
    <li>
      <a href="#." class="photo"><img src="images/hover-cart.jpg" class="cart-thumb" alt="" /></a>
      <h6><a href="#.">Sacrificial Chair Design </a></h6>
      <p>Qty: 2 <span class="price">$170.00</span></p>
    </li>
    <li class="total clearfix">
      <div class="pull-right"><strong>Shipping</strong>: $5.00</div>
      <div class="pull-left"><strong>Total</strong>: $173.00</div>
      </li>
      <li class="cart-btn">
      <a href="#." class="active">VIEW CART </a>
      <a href="#.">CHECKOUT </a>
    </li>
  </ul>
    </div>   
  </nav>
</header>



<!--Page Header-->
<section class="header_layout2 padding">
  <div class="container">
    <div class="header_content padding">
      <div class="row">
        <div class="col-md-12 text-center">
           <h2 class="heading_space uppercase">creative design<strong>lighting furniture</strong></h2>
           <h3 class="content_space">Typi non habent claritatem insitam.</h3>
           <a href="#." class="btn-common uppercase">view collection</a> 
        </div>
      </div>
    </div>
  </div>
</section>


<!--Page Nav-->
<section class="page_menu">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h3 class="hidden">hidden</h3>
        <ul class="breadcrumb">
          <li><a href="index.html">Home</a></li>
          <li class="active">Products</li>
        </ul>
      </div>
    </div>
  </div>
</section>


<section class="grid padding">
  <div class="container">
    <div class="row">
      <div class="col-sm-8">
        <div class="shop-grid-controls">
          <a class="side-button bottom30" href="#.">
            Show Sidebar
          </a>
          <div class="view-button grid bottom30">
            <i class="fa fa-th-large"></i>
          </div>
          <div class="view-button active list bottom30">
            <i class="fa fa-align-justify"></i>
          </div>
          <div class="entry bottom30">
          <form class="grid-form">
              <div class="form-group">
                <div class="select form-control">
                  <select name="country" id="city">
                  <option selected>Defaul sorting</option>
                  <option>Defaul sorting</option>
                  <option>Defaul sorting</option>
                  </select>
                </div>
              </div>
          </form>
          </div>
        </div>
      </div>
      <div class="col-sm-4 text-right">
         <h5 class="result uppercase bottom30">Showing 1-12 of 20 relults</h5>
      </div>
    </div>  
    <div class="row shop-grid list-view">
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <div class="tag">
                <div class="tag-btn">
                <span class="uppercase text-center">New</span>
                </div>
              </div>
            <a class="fancybox" href="images/product5.jpg"><img src="images/product5.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
             <p class="title">Sacrificial Chair Design </p>
             <div class="list_content">
               <h4 class="bottom30">Sacrificial Chair Design </h4>
               <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
               feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
                dolore te feugait nulla facilisi. </p>
                <ul class="review_list bottomtop30">
                  <li><img alt="star" src="images/star.png"></li>
                  <li><a href="#.">10 review(s) </a></li>
                  <li><a href="#.">Add your review</a></li>
                </ul>
                <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
                <div class="cart-buttons">
                  <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                  <a class="icons" href="#.">
                  <i class="fa fa-heart-o"></i>
                  </a>
                  <a class="icons" href="#.">
                  <i class="fa fa-exchange"></i>
                  </a>
                </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product5.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product6.jpg"><img src="images/product6.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#."><i class="fa fa-heart-o"></i></a>
                <a class="icons" href="#."><i class="fa fa-exchange"></i></a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product6.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product7.jpg"><img src="images/product7.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></span>
           <a class="fancybox" href="images/product7.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product8.jpg"><img src="images/product8.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product8.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product1.jpg"><img src="images/product1.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product1.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <div class="tag">
                <div class="tag-btn">
                <span class="uppercase text-center">New</span>
                </div>
              </div>
            <a class="fancybox" href="images/product3.jpg"><img src="images/product3.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product3.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product2.jpg"><img src="images/product2.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product2.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <a class="fancybox" href="images/product4.jpg"><img src="images/product4.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product4.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image"
            <a class="fancybox" href="images/product9.jpg"><img src="images/product9.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product9.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
           <a class="fancybox" href="images/product5.jpg"> <img src="images/product5.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product5.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>                 
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <div class="tag">
                <div class="tag-btn">
                <span class="uppercase text-center">New</span>
                </div>
              </div>
           <a class="fancybox" href="images/product8.jpg"> <img src="images/product8.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product8.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="product_wrap heading_space">
          <div class="image">
            <div class="tag">
                <div class="tag-btn">
                <span class="uppercase text-center">New</span>
                </div>
              </div>
            <a class="fancybox" href="images/product1.jpg"><img src="images/product1.jpg" alt="Product" class="img-responsive"></a>
          </div>
          <div class="product_desc">
           <p class="title">Sacrificial Chair Design </p>
           <div class="list_content">
             <h4 class="bottom30">Sacrificial Chair Design </h4>
             <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu 
             feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis
              dolore te feugait nulla facilisi. </p>
              <ul class="review_list bottomtop30">
                <li><img alt="star" src="images/star.png"></li>
                <li><a href="#.">10 review(s) </a></li>
                <li><a href="#.">Add your review</a></li>
              </ul>
              <h4 class="price bottom30"><i class="fa fa-gbp"></i>170.00 &nbsp;<span class="discount"><i class="fa fa-gbp"></i>170.00</span></h4>
              <div class="cart-buttons">
                <a class="uppercase border-radius btn-dark" href="cart.html"><i class="fa fa-shopping-basket"></i> &nbsp; Add to cart</a>
                <a class="icons" href="#.">
                <i class="fa fa-heart-o"></i>
                </a>
                <a class="icons" href="#.">
                <i class="fa fa-exchange"></i>
                </a>
              </div>
           </div>
           <span class="price"><i class="fa fa-gbp"></i>170.00</span>
           <a class="fancybox" href="images/product1.jpg" data-fancybox-group="gallery"><i class="fa fa-shopping-bag open"></i></a>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 col-sm-6">
        <ul class="pager">
          <li><a href="#."><i class="fa fa-angle-left"></i></a></li>
          <li class="active"><a href="#.">01</a></li>
          <li><a href="#.">02</a></li>
          <li><a href="#.">03</a></li>
          <li><a href="#."><i class="fa fa-angle-right"></i></a></li>
        </ul>
      </div>
       <div class="col-md-6 col-sm-6 text-right">
         <h5 class="result uppercase">Showing 1-12 of 20 relults</h5>
      </div>
    </div>
  </div>
</section>




<!--Footer-->
<footer class="padding_top bottom_half">
  <a href="#." class="go-top text-center"><i class="fa fa-angle-double-up"></i></a>
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel content_space">
          <h4 class="heading_border heading_space">about store</h4>
          <ul class="about_foot">
           <li><i class="fa fa-home"></i>234 Heaven Stress, Beverly Hill.</li>
           <li><i class="fa fa-phone"></i>800) 123 456 789</li>
           <li><a href="#."><i class="fa fa-envelope-o"></i>Contact@erentheme.com</a></li>
           <li>
             <span><img src="images/paymennt1.png" alt="payment"></span> 
             <span><img src="images/payment2.png" alt="payment"></span> 
             <span><img src="images/payment3.jpg" alt="payment"></span> 
             <span><img src="images/payment4.png" alt="payment"></span> 
             <span><img src="images/payment5.png" alt="payment"></span>
           </li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel content_space">
          <h4 class="heading_border heading_space">My Account</h4>
          <ul class="account_foot">
           <li><a href="#.">My Account</a></li>
           <li><a href="#.">Login</a></li>
           <li><a href="#.">My Cart</a></li>
           <li><a href="#.">Wishlist</a></li>
           <li><a href="#.">Checkout</a></li>
           <li><a href="#.">Userinfo</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel content_space">
          <h4 class="heading_border heading_space">INFORMATION</h4>
          <ul class="account_foot">
           <li><a href="#.">My Account</a></li>
           <li><a href="#.">Login</a></li>
           <li><a href="#.">My Cart</a></li>
           <li><a href="#.">Wishlist</a></li>
           <li><a href="#.">Checkout</a></li>
           <li><a href="#.">Userinfo</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer_panel content_space">
          <h4 class="heading_border heading_space">Customer Service</h4>
          <ul class="account_foot">
           <li><a href="#.">Shipping Policy</a></li>
           <li><a href="#.">Compensation First</a></li>
           <li><a href="#.">My Account</a></li>
           <li><a href="#.">Return Policy</a></li>
           <li><a href="#.">Contact Us</a></li>
           <li><a href="#.">Shipping Info</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>
<div class="copyright">
  <div class="container">
    <div class="row">
      <div class="col-sm-4">
        <p>Copyright &copy; 2016 <a href="#.">Eren</a>. All Right Reserved.</p>
      </div>
      <div class="col-sm-8">
        <ul class="social">
          <li><a href="#."><i class="fa fa-facebook"></i></a></li>
          <li><a href="#."><i class="fa fa-twitter"></i></a></li>
          <li><a href="#."><i class="fa fa-rss"></i></a></li>
          <li><a href="#."><i class="fa fa-google-plus"></i></a></li>
          <li><a href="#."><i class="fa fa-linkedin"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>


<script src="js/jquery-2.2.3.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOBKD6V47-g_3opmidcmFapb3kSNAR70U"></script>
<script src="js/gmap3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/jquery.parallax-1.1.3.js"></script>
<script src="js/jquery.appear.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.cubeportfolio.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/revolution.extension.layeranimation.min.js"></script>
<script src="js/revolution.extension.navigation.min.js"></script>
<script src="js/revolution.extension.parallax.min.js"></script>
<script src="js/revolution.extension.slideanims.min.js"></script>
<script src="js/revolution.extension.video.min.js"></script>
<script src="js/kinetic.js"></script>
<script src="js/jquery.final-countdown.js"></script>

<script src="js/functions.js"></script>

</body>
</html>
